package org.shin.generator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DictionaryGenerator {

    public static void main(String[] args) {
        String[] tablesName = { "role" };

        String url = "jdbc:mysql://115.159.1.60:4040/ylpt?useUnicode=true&characterEncoding=UTF-8&zeroDateTimeBehavior=convertToNull";
        String user = "ucmed";
        String password = "txtest@mysql";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
            StringBuffer res = new StringBuffer();
            for(int i = 0; i < tablesName.length; i++) {
                String tableName = tablesName[i];
                String sql = "use information_schema; ";
                String cl = "select * from columns where table_name = '"
                        + tableName + "';";
                stmt.execute(sql);
                rs = stmt.executeQuery(cl);
                res.append("\nh3. " + tableName
                        + "\n|_.字段|_.格式|_.字段含义|_.允许为空|_.备注|\n");
                while(rs.next()) {
                    String columnName = rs.getString("COLUMN_NAME");
                    String isNullable = rs.getString("IS_NULLABLE");
                    String columnType = rs.getString("COLUMN_TYPE");
                    String columnComment = rs.getString("COLUMN_COMMENT");
                    res.append("|" + columnName);
                    res.append("|" + columnType);
                    res.append("|" + columnComment);
                    res.append("|" + isNullable);
                    res.append("||\n");
                    /*
                     * System.out.print(rs.getString("COLUMN_NAME") + "   ");
                     * System.out.print(rs.getString("IS_NULLABLE") + "   ");
                     * System.out.print(rs.getString("COLUMN_TYPE") + "   ");
                     * System.out.println(rs.getString("COLUMN_COMMENT") + "   ");
                     */
                }
            }

            System.out.println(res.toString());
        } catch(Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                stmt.close();
                conn.close();
            } catch(SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
